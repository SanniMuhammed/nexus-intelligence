
  # Nexus Intelligence Dashboard Design

  This is a code bundle for Nexus Intelligence Dashboard Design. The original project is available at https://www.figma.com/design/b7XJ0RanGM7u6tCzMtz9BB/Nexus-Intelligence-Dashboard-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  